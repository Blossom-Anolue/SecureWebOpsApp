const CONFIG = {
  apiBaseUrl: "https://securewebops.gannon.link",
  appBaseUrl: "https://securewebops.gannon.link",
  supabaseUrl: "https://culznwivxwtvrmohstht.supabase.co",
  supabasePublishableKey: "sb_publishable_m_7Q5T4ZLLuFsiZK7-N1xw_V7KbRTBx",
  projectId: "culznwivxwtvrmohstht",
};

const STORAGE_KEYS = {
  session: "securewebopsExtensionSession",
  lastScanId: "securewebopsLastScanId",
  lastScanResult: "securewebopsLastScanResult",
  mailboxStatus: "securewebopsMailboxStatus",
};

const dom = {};
let pageContext = { subject: "", replyToEmail: "", links: [] };

document.addEventListener("DOMContentLoaded", async () => {
  bindElements();
  bindEvents();
  setupTabs();

  const session = await getValidSession();
  renderAuthState(session);

  if (session) {
    const storedResult = await getStorageValue(STORAGE_KEYS.lastScanResult);
    if (storedResult) renderWebResult(storedResult);
  }

  const mailboxStatus = await getStorageValue(STORAGE_KEYS.mailboxStatus);
  renderMailboxStatus(mailboxStatus);

  setStatus("Ready.");
});

function bindElements() {
  // Tabs
  dom.tabBtns = Array.from(document.querySelectorAll(".tabBtn"));
  dom.tabPanels = {
    email: document.getElementById("emailTab"),
    web: document.getElementById("webTab"),
  };

  // Email analysis
  dom.emailText = document.getElementById("emailText");
  dom.senderEmail = document.getElementById("senderEmail");
  dom.scanVisible = document.getElementById("scanVisible");
  dom.scanManual = document.getElementById("scanManual");
  dom.emailLoading = document.getElementById("emailLoading");
  dom.emailResult = document.getElementById("emailResult");

  // Mailbox status
  dom.mailboxProtectionState = document.getElementById("mailboxProtectionState");
  dom.mailboxSaveState = document.getElementById("mailboxSaveState");
  dom.mailboxLastScore = document.getElementById("mailboxLastScore");
  dom.mailboxProvider = document.getElementById("mailboxProvider");

  // Auth + web scan
  dom.authSection = document.getElementById("authSection");
  dom.loggedOutView = document.getElementById("loggedOutView");
  dom.loggedInView = document.getElementById("loggedInView");
  dom.authEmail = document.getElementById("authEmail");
  dom.authPassword = document.getElementById("authPassword");
  dom.signInBtn = document.getElementById("signInBtn");
  dom.signOutBtn = document.getElementById("signOutBtn");
  dom.accountEmail = document.getElementById("accountEmail");
  dom.scanSection = document.getElementById("scanSection");
  dom.urlInput = document.getElementById("urlInput");
  dom.scanBtn = document.getElementById("scanBtn");
  dom.openDashboard = document.getElementById("openDashboard");
  dom.resultSection = document.getElementById("resultSection");
  dom.scoreRing = document.getElementById("scoreRing");
  dom.scoreValue = document.getElementById("scoreValue");
  dom.resultTarget = document.getElementById("resultTarget");
  dom.resultRisk = document.getElementById("resultRisk");
  dom.criticalCount = document.getElementById("criticalCount");
  dom.highCount = document.getElementById("highCount");
  dom.mediumCount = document.getElementById("mediumCount");
  dom.lowCount = document.getElementById("lowCount");

  dom.status = document.getElementById("status");
}

function bindEvents() {
  dom.scanVisible.addEventListener("click", handleScanVisibleEmail);
  dom.scanManual.addEventListener("click", handleScanPasted);
  dom.signInBtn.addEventListener("click", handleSignIn);
  dom.signOutBtn.addEventListener("click", handleSignOut);
  dom.scanBtn.addEventListener("click", handleWebScan);
  dom.openDashboard.addEventListener("click", handleOpenDashboard);
}

function setupTabs() {
  for (const btn of dom.tabBtns) {
    btn.addEventListener("click", () => {
      for (const b of dom.tabBtns) b.classList.toggle("active", b === btn);
      const target = btn.getAttribute("data-tab");
      for (const [name, panel] of Object.entries(dom.tabPanels)) {
        panel.classList.toggle("hidden", name !== target);
      }
    });
  }
}

function setStatus(message) {
  dom.status.textContent = message;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>'"]/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;"
  }[c]));
}

/* ----------------- Email phishing analysis (local browser rules) ----------------- */

function setEmailLoading(isLoading) {
  dom.emailLoading.classList.toggle("hidden", !isLoading);
  dom.scanVisible.disabled = isLoading;
  dom.scanManual.disabled = isLoading;
}

function verdictClass(verdict) {
  const v = String(verdict || "").toLowerCase();
  if (v === "phishing" || v === "high") return "phishing";
  if (v === "suspicious" || v === "medium") return "suspicious";
  return "safe";
}

function renderEmailResult(data) {
  dom.emailResult.className = `result ${verdictClass(data.verdict)}`;
  dom.emailResult.classList.remove("hidden");

  const reasons = (data.reasons || []).map(r => `<li>${escapeHtml(r)}</li>`).join("")
    || "<li>No reasons provided.</li>";
  const urls = (data.urlsChecked || []).map(u => `<li>${escapeHtml(u)}</li>`).join("")
    || "<li>No URLs found.</li>";

  dom.emailResult.innerHTML = `
    <strong>Final Verdict: ${escapeHtml(data.verdict || "Unknown")}</strong>
    <div class="score">${data.score ?? "—"}%</div>
    <div class="small">
      Analysis Source: Local browser rules ·
      Links: ${data.linkHeuristicScore ?? "—"}%
    </div>
    <h3>Why?</h3>
    <ul>${reasons}</ul>
    <h3>URLs Checked</h3>
    <ul>${urls}</ul>
  `;
}

async function analyzeEmail() {
  const text = dom.emailText.value.trim();
  if (!text) {
    dom.emailResult.className = "result suspicious";
    dom.emailResult.classList.remove("hidden");
    dom.emailResult.innerHTML = "Paste an email or click <strong>Scan Visible Email</strong>.";
    return;
  }

  setEmailLoading(true);
  dom.emailResult.classList.add("hidden");

  try {
    const result = window.PhishGuardRules.analyzeEmail({
      subject: pageContext.subject || text.slice(0, 100),
      bodyText: text,
      senderEmail: dom.senderEmail.value.trim(),
      replyToEmail: pageContext.replyToEmail || "",
      links: pageContext.links || [],
    });

    const data = {
      verdict: result.verdict,
      score: result.score,
      reasons: result.reasons.length ? result.reasons : ["No major phishing indicators were detected by local rules."],
      urlsChecked: result.urlsChecked,
      emailTextApiRiskScore: "Local",
      urlApiRiskScore: "Local",
      linkHeuristicScore: result.linkHeuristicScore,
    };

    renderEmailResult(data);
    setStatus(`Email verdict: ${data.verdict} (${data.score}%) — local analysis`);
  } catch (error) {
    dom.emailResult.className = "result phishing";
    dom.emailResult.classList.remove("hidden");
    dom.emailResult.innerHTML = `<strong>Error:</strong> ${escapeHtml(error.message)}`;
  } finally {
    setEmailLoading(false);
  }
}
async function handleScanVisibleEmail() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  chrome.tabs.sendMessage(tab.id, { action: "GET_EMAIL_DATA" }, (response) => {
    if (chrome.runtime.lastError || !response?.emailText) {
      dom.emailResult.className = "result suspicious";
      dom.emailResult.classList.remove("hidden");
      dom.emailResult.innerHTML =
        "Could not read the page. Open an email in Gmail or Outlook, then try again.";
      return;
    }
    dom.emailText.value = response.emailText;
    if (response.senderEmail && !dom.senderEmail.value) {
      dom.senderEmail.value = response.senderEmail;
    }
    pageContext = {
      subject: response.subject || "",
      replyToEmail: response.replyToEmail || "",
      links: response.links || [],
    };
    analyzeEmail();
  });
}

function handleScanPasted() {
  pageContext = { subject: "", replyToEmail: "", links: [] };
  analyzeEmail();
}

/* ----------------- Mailbox status ----------------- */

function formatRelativeMailboxTime(isoString) {
  if (!isoString) return "";
  const diffMs = Date.now() - new Date(isoString).getTime();
  if (!Number.isFinite(diffMs) || diffMs < 0) return "";
  const diffMinutes = Math.round(diffMs / 60000);
  if (diffMinutes < 1) return "just now";
  if (diffMinutes === 1) return "1 min ago";
  if (diffMinutes < 60) return `${diffMinutes} mins ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours === 1) return "1 hour ago";
  return `${diffHours} hours ago`;
}

function renderMailboxStatus(mailboxStatus) {
  const recent =
    mailboxStatus?.lastSeenAt &&
    Date.now() - new Date(mailboxStatus.lastSeenAt).getTime() < 5 * 60 * 1000;
  const protectionText =
    recent && mailboxStatus?.active
      ? `Active on ${mailboxStatus.provider || "mailbox"}`
      : "Open Gmail or Outlook";

  let saveText = "No mailbox result yet";
  if (mailboxStatus?.saveStatus === "saved") {
    saveText = `Saved ${formatRelativeMailboxTime(mailboxStatus.savedAt)}`.trim();
  } else if (mailboxStatus?.saveStatus === "sign_in_required") {
    saveText = "Sign in to save";
  } else if (mailboxStatus?.saveStatus === "save_failed") {
    saveText = "Save failed";
  } else if (mailboxStatus?.saveStatus === "not_saved" && mailboxStatus?.lastAnalyzedAt) {
    saveText = "Local + AI analysis";
  }

  const scoreText =
    mailboxStatus?.lastScore != null
      ? `${mailboxStatus.lastScore}/100${mailboxStatus.saveStatus === "saved" ? "" : ""}`
      : "--";

  dom.mailboxProtectionState.textContent = protectionText;
  dom.mailboxSaveState.textContent = saveText;
  dom.mailboxLastScore.textContent = scoreText;
  dom.mailboxProvider.textContent = mailboxStatus?.provider
    ? mailboxStatus.provider.charAt(0).toUpperCase() + mailboxStatus.provider.slice(1)
    : "Gmail / Outlook";
}

/* ----------------- Auth + web scan (SecureWebOps) ----------------- */

function renderAuthState(session) {
  const loggedIn = !!session?.access_token;
  dom.loggedOutView.classList.toggle("hidden", loggedIn);
  dom.loggedInView.classList.toggle("hidden", !loggedIn);
  dom.scanSection.classList.toggle("hidden", !loggedIn);
  if (loggedIn) {
    dom.accountEmail.textContent = session.user?.email || "Signed in";
  } else {
    dom.accountEmail.textContent = "";
    dom.resultSection.classList.add("hidden");
  }
}

function scoreColor(score) {
  if (score >= 85) return "#28c76f";
  if (score >= 60) return "#f59e0b";
  return "#ef4444";
}

function renderWebResult(result) {
  const score = Number(result?.score ?? 0);
  const degrees = Math.max(0, Math.min(100, score)) * 3.6;
  const color = scoreColor(score);

  dom.resultSection.classList.remove("hidden");
  dom.scoreRing.style.background = `conic-gradient(${color} ${degrees}deg, #173456 ${degrees}deg)`;
  dom.scoreValue.textContent = Number.isFinite(score) ? String(score) : "--";
  dom.resultTarget.textContent = result?.targetUrl || "Latest scan";
  dom.resultRisk.textContent = `Risk: ${result?.risk || "unknown"}`;
  dom.criticalCount.textContent = String(result?.counts?.critical || 0);
  dom.highCount.textContent = String(result?.counts?.high || 0);
  dom.mediumCount.textContent = String(result?.counts?.medium || 0);
  dom.lowCount.textContent = String(result?.counts?.low || 0);
}

function normalizeUrl(input) {
  let value = (input || "").trim();
  if (!value) return null;
  if (!value.startsWith("http://") && !value.startsWith("https://")) {
    value = `https://${value}`;
  }
  try {
    const url = new URL(value);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

async function setStorageValue(key, value) {
  await chrome.storage.local.set({ [key]: value });
}

async function getStorageValue(key) {
  const data = await chrome.storage.local.get([key]);
  return data[key] ?? null;
}

async function removeStorageKeys(keys) {
  await chrome.storage.local.remove(keys);
}

async function signInWithPassword(email, password) {
  const response = await fetch(`${CONFIG.supabaseUrl}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: CONFIG.supabasePublishableKey,
      Authorization: `Bearer ${CONFIG.supabasePublishableKey}`,
    },
    body: JSON.stringify({ email, password }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.msg || payload?.error_description || payload?.error || "Sign in failed");
  }
  return payload;
}

async function refreshSession(refreshToken) {
  const response = await fetch(`${CONFIG.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: CONFIG.supabasePublishableKey,
      Authorization: `Bearer ${CONFIG.supabasePublishableKey}`,
    },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.msg || payload?.error_description || payload?.error || "Session refresh failed");
  }
  return payload;
}

async function getValidSession() {
  const session = await getStorageValue(STORAGE_KEYS.session);
  if (!session?.access_token) return null;

  const expiresAt = Number(session.expires_at || 0);
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (expiresAt && expiresAt - nowSeconds > 60) return session;
  if (!session.refresh_token) {
    await removeStorageKeys([STORAGE_KEYS.session]);
    return null;
  }

  try {
    const refreshed = await refreshSession(session.refresh_token);
    await setStorageValue(STORAGE_KEYS.session, refreshed);
    return refreshed;
  } catch {
    await removeStorageKeys([STORAGE_KEYS.session]);
    return null;
  }
}

async function callExtensionEventApi(session, eventType, details = {}) {
  try {
    await fetch(`${CONFIG.apiBaseUrl}/api/extension/events`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ eventType, details }),
    });
  } catch (error) {
    console.error("Failed to log extension event", error);
  }
}

async function handleSignIn() {
  const email = dom.authEmail.value.trim();
  const password = dom.authPassword.value;
  if (!email || !password) {
    setStatus("Enter your email and password.");
    return;
  }

  dom.signInBtn.disabled = true;
  setStatus("Signing in...");

  try {
    const session = await signInWithPassword(email, password);
    await setStorageValue(STORAGE_KEYS.session, session);
    renderAuthState(session);
    await callExtensionEventApi(session, "extension.sign_in", {
      email: session.user?.email || email,
    });
    await chrome.runtime.sendMessage({ type: "SYNC_SESSION_TO_APP", session });
    setStatus("Signed in. Mailbox phishing checks will now save to your dashboard.");
  } catch (error) {
    setStatus(error?.message || "Sign in failed.");
  } finally {
    dom.signInBtn.disabled = false;
  }
}

async function handleSignOut() {
  const session = await getStorageValue(STORAGE_KEYS.session);
  if (session?.access_token) {
    await callExtensionEventApi(session, "extension.sign_out", {
      email: session.user?.email || null,
    });
  }
  await removeStorageKeys([
    STORAGE_KEYS.session,
    STORAGE_KEYS.lastScanId,
    STORAGE_KEYS.lastScanResult,
    STORAGE_KEYS.mailboxStatus,
  ]);
  dom.authEmail.value = "";
  dom.authPassword.value = "";
  dom.urlInput.value = "";
  renderAuthState(null);
  renderMailboxStatus(null);
  await chrome.runtime.sendMessage({ type: "CLEAR_SESSION_IN_APP" });
  setStatus("Signed out.");
}

async function queueScan(session, targetUrl) {
  const response = await fetch(`${CONFIG.apiBaseUrl}/api/scan`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ target_url: targetUrl, scan_type: "quick" }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.error?.message || `Scan failed with status ${response.status}`);
  }
  return payload;
}

async function fetchScanStatus(scanId) {
  const session = await getValidSession();
  const response = await fetch(`${CONFIG.apiBaseUrl}/api/scans/v1/scans/${scanId}`, {
    headers: session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {},
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.error?.message || payload?.error || `Status check failed with ${response.status}`);
  }
  return payload;
}

async function fetchScanResults(scanId) {
  const session = await getValidSession();
  const response = await fetch(`${CONFIG.apiBaseUrl}/api/scans/v1/scans/${scanId}/results`, {
    headers: session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {},
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.error?.message || payload?.error || `Result fetch failed with ${response.status}`);
  }
  return payload;
}

async function pollForResults(session, scanId, targetUrl) {
  const maxAttempts = 40;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const scan = await fetchScanStatus(scanId);
    if (scan.status === "completed") {
      const result = await fetchScanResults(scanId);
      const rawScore = result?.summary?.score ?? 0;
      const score = Math.round(rawScore);
      const counts = result?.summary?.issue_counts || { critical: 0, high: 0, medium: 0, low: 0 };
      const normalizedResult = {
        scanId, targetUrl, score,
        risk: result?.summary?.risk || "unknown",
        counts,
      };
      await setStorageValue(STORAGE_KEYS.lastScanResult, normalizedResult);
      renderWebResult(normalizedResult);
      await callExtensionEventApi(session, "extension.scan_result_viewed", {
        scanId, targetUrl, score, counts,
      });
      setStatus(`Scan complete. Score: ${score}/100`);
      return;
    }
    if (scan.status === "failed" || scan.status === "canceled") {
      throw new Error(scan.error || "Scan failed.");
    }
    setStatus(`Scanning... (${scan.status})`);
    await new Promise((resolve) => setTimeout(resolve, 3000));
  }
  throw new Error("Scan is still running. Reopen the extension in a moment to check again.");
}

async function handleWebScan() {
  const targetUrl = normalizeUrl(dom.urlInput.value);
  if (!targetUrl) {
    setStatus("Enter a valid URL.");
    return;
  }
  const session = await getValidSession();
  if (!session) {
    renderAuthState(null);
    setStatus("Sign in first.");
    return;
  }
  dom.scanBtn.disabled = true;
  setStatus("Queueing scan...");
  try {
    const queued = await queueScan(session, targetUrl);
    const scanId = queued.scanId || queued.scan_id;
    await setStorageValue(STORAGE_KEYS.lastScanId, scanId);
    await callExtensionEventApi(session, "extension.scan_queued", {
      scanId, targetUrl, scanType: "quick",
    });
    setStatus("Scan queued. Waiting for results...");
    await pollForResults(session, scanId, targetUrl);
  } catch (error) {
    setStatus(error?.message || "Scan failed.");
  } finally {
    dom.scanBtn.disabled = false;
  }
}

async function handleOpenDashboard() {
  const session = await getValidSession();
  if (session) {
    await chrome.runtime.sendMessage({ type: "SYNC_SESSION_TO_APP", session });
  }
  await chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" });
}
