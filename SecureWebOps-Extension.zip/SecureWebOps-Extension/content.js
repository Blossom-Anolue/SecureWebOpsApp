/* SecureWebOps combined content script.
 * - Auto-detects open Gmail/Outlook email.
 * - Uses local PhishGuardRules heuristics directly inside the browser.
 * - No local backend server is required.
 * - Shows in-page SecureWebOps banner with the verdict.
 * - Highlights risky phrases inside the email body.
 * - Saves the result to the user's SecureWebOps dashboard when signed in.
 */

const SUPABASE_FUNCTION_URL =
  "https://culznwivxwtvrmohstht.supabase.co/functions/v1/analyze-phishing";
const SESSION_KEY = "securewebopsExtensionSession";
const MAILBOX_STATUS_KEY = "securewebopsMailboxStatus";
const BANNER_ID = "swo-phishing-banner";

const AUTO_SCAN_DELAY_MS = 1500;
const MIN_EMAIL_LENGTH = 40;
const MAX_BODY_LENGTH = 8000;

const RISKY_PHRASES = [
  "urgent", "immediately", "verify your account", "account suspended", "account suspension",
  "password reset", "reset your password", "confirm your password", "update your password",
  "login to continue", "sign in to continue", "unusual activity", "suspicious activity",
  "payment failed", "payment overdue", "billing problem", "invoice attached",
  "click here", "act now", "limited time", "final warning", "security alert",
  "validate your account", "confirm your identity", "your account will be closed",
  "wire transfer", "gift card", "bank account", "social security", "ssn",
  "credential", "credentials", "re-enter your information",
];

let lastScannedHash = "";
let scanTimer = null;
let isScanning = false;

function qs(sel, root = document) { return root.querySelector(sel); }
function qsa(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

function escapeHtml(str) {
  return String(str).replace(/[&<>'"]/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;",
  }[c]));
}

function detectProvider() {
  const host = location.hostname.toLowerCase();
  if (host.includes("mail.google.com")) return "gmail";
  if (host.includes("outlook.")) return "outlook";
  return "unknown";
}

const gmailAdapter = {
  isEmailOpen() {
    return !!(qs("div.a3s") || qs("h2.hP") || qs("h2[data-thread-perm-id]"));
  },
  getSubject() {
    const h2 = qs("h2.hP") || qs("h2[data-thread-perm-id]");
    return (h2?.textContent || "").trim();
  },
  getSenderEmail() {
    const senderEl = qs(".gD") || qs("[email]");
    const emailAttr = senderEl?.getAttribute("email");
    if (emailAttr) return emailAttr.trim();
    const aria = senderEl?.getAttribute("aria-label") || "";
    const m = aria.match(/<([^>]+@[^>]+)>/);
    return m ? m[1].trim() : "";
  },
  getReplyToEmail() {
    const header = qs(".gE.iv.gt") || qs(".adn.ads");
    if (!header) return "";
    const m = (header.textContent || "").match(/reply-to:\s*([^\s<>]+@[^\s<>]+)/i);
    return m ? m[1].trim() : "";
  },
  getBodyContainer() {
    return qs("div.a3s") || qs("div[role='listitem'] div.a3s") || qs("[role='main']");
  },
  getBodyText() {
    const body = this.getBodyContainer();
    return (body?.innerText || body?.textContent || "").trim();
  },
  getLinks() {
    const bodyRoot = this.getBodyContainer() || document;
    const links = [];
    for (const a of qsa("a[href]", bodyRoot)) {
      let href = a.getAttribute("href") || "";
      try {
        const u = new URL(href);
        if (u.hostname === "www.google.com" && u.pathname === "/url") {
          const q = u.searchParams.get("q");
          if (q) href = q;
        }
      } catch {}
      const mismatch = window.PhishGuardRules?.displayVsHrefMismatch({
        textContent: a.textContent || "",
        getAttribute: (k) => (k === "href" ? href : a.getAttribute(k)),
      });
      links.push({ href, text: (a.textContent || "").trim().slice(0, 120), mismatch });
    }
    return links;
  },
  getInjectionPoint() {
    return qs(".nH .adn") || qs("div[role='main']") || document.body;
  },
};

const outlookAdapter = {
  isEmailOpen() {
    return !!(
      qs("div[role='main']") &&
      (qs("div[role='document']") ||
        qs("div[aria-label*='Message body']") ||
        qs("article") ||
        qs("iframe"))
    );
  },
  getSubject() {
    const main = qs("div[role='main']") || document;
    const h1 = qs("h1", main);
    if (h1?.textContent?.trim()) return h1.textContent.trim();
    const heading = qs("div[role='heading']", main);
    return (heading?.textContent || "").trim();
  },
  getSenderEmail() {
    const main = qs("div[role='main']") || document;
    const candidate =
      qs("[data-testid='message-from']", main) ||
      qs("[aria-label^='From']", main) ||
      qs("span[title*='@']", main) ||
      qs("div[title*='@']", main);
    const t = (candidate?.getAttribute("title") || candidate?.textContent || "").trim();
    const m = t.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
    return m ? m[0] : "";
  },
  getReplyToEmail() {
    const main = qs("div[role='main']") || document;
    const m = (main.innerText || "").match(/reply[-\s]?to[:\s]+([^\s<>]+@[^\s<>]+)/i);
    return m ? m[1].trim() : "";
  },
  getBodyContainer() {
    const main = qs("div[role='main']") || document;
    return (
      qs("div[aria-label*='Message body']", main) ||
      qs("div[role='document']", main) ||
      qs("article", main) ||
      qs("div[data-testid='message-body']", main) ||
      main
    );
  },
  getBodyText() {
    const main = qs("div[role='main']") || document;
    const body = this.getBodyContainer();
    let text = (body?.innerText || "").trim();
    if (text) return text;
    for (const frame of qsa("iframe", main)) {
      try {
        const doc = frame.contentDocument;
        const frameBody = doc?.querySelector("div[role='document']") || doc?.body;
        const t = (frameBody?.innerText || "").trim();
        if (t && t.length > 40) return t;
      } catch {}
    }
    return "";
  },
  getLinks() {
    const bodyRoot = this.getBodyContainer() || document;
    const links = [];
    for (const a of qsa("a[href]", bodyRoot)) {
      const href = a.getAttribute("href") || "";
      const mismatch = window.PhishGuardRules?.displayVsHrefMismatch({
        textContent: a.textContent || "",
        getAttribute: (k) => (k === "href" ? href : a.getAttribute(k)),
      });
      links.push({ href, text: (a.textContent || "").trim().slice(0, 120), mismatch });
    }
    return links;
  },
  getInjectionPoint() {
    return qs("div[role='main']") || document.body;
  },
};

function getAdapter() {
  const p = detectProvider();
  if (p === "gmail") return gmailAdapter;
  if (p === "outlook") return outlookAdapter;
  return null;
}

function extractEmailData() {
  const adapter = getAdapter();
  if (!adapter || !adapter.isEmailOpen()) {
    const root = qs("[role='main']") || document.body;
    const text = (root.innerText || root.textContent || "").trim().slice(0, 15000);
    return {
      subject: "",
      senderEmail: "",
      replyToEmail: "",
      bodyText: text,
      links: [],
      container: root,
      injectionPoint: document.body,
      provider: "unknown",
      adapterAvailable: false,
    };
  }
  return {
    subject: adapter.getSubject(),
    senderEmail: adapter.getSenderEmail(),
    replyToEmail: adapter.getReplyToEmail(),
    bodyText: (adapter.getBodyText() || "").slice(0, 15000),
    links: adapter.getLinks(),
    container: adapter.getBodyContainer(),
    injectionPoint: adapter.getInjectionPoint(),
    provider: detectProvider(),
    adapterAvailable: true,
  };
}

function simpleHash(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash |= 0;
  }
  return String(hash);
}

function removeOldHighlights() {
  document.querySelectorAll("mark.securewebops-phish-highlight").forEach((mark) => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightRiskyText(root) {
  removeOldHighlights();
  if (!root) return;

  const phrasePattern = RISKY_PHRASES
    .map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .sort((a, b) => b.length - a.length)
    .join("|");
  const regex = new RegExp(`\\b(${phrasePattern})\\b`, "gi");

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent) return NodeFilter.FILTER_REJECT;
      if (["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "MARK"].includes(parent.tagName)) {
        return NodeFilter.FILTER_REJECT;
      }
      if (!regex.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
      regex.lastIndex = 0;
      return NodeFilter.FILTER_ACCEPT;
    },
  });

  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);

  for (const node of textNodes) {
    const frag = document.createDocumentFragment();
    const text = node.nodeValue;
    let lastIndex = 0;
    text.replace(regex, (match, _p1, offset) => {
      frag.appendChild(document.createTextNode(text.slice(lastIndex, offset)));
      const mark = document.createElement("mark");
      mark.className = "securewebops-phish-highlight";
      mark.title = "SecureWebOps phishing indicator";
      mark.textContent = match;
      frag.appendChild(mark);
      lastIndex = offset + match.length;
      return match;
    });
    frag.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(frag, node);
  }
}

function injectStyles() {
  if (document.getElementById("securewebops-style")) return;
  const style = document.createElement("style");
  style.id = "securewebops-style";
  style.textContent = `
    .securewebops-phish-highlight {
      background: #ffe066 !important;
      color: #111 !important;
      border-bottom: 2px solid #d9480f !important;
      padding: 0 2px !important;
      border-radius: 3px !important;
    }
  `;
  document.documentElement.appendChild(style);
}

function verdictToLevel(verdict, score) {
  const v = String(verdict || "").toLowerCase();
  if (v === "phishing" || v === "high") return "high";
  if (v === "suspicious" || v === "medium") return "medium";
  if (v === "safe" || v === "low") return "low";
  if (typeof score === "number") {
    if (score >= 70) return "high";
    if (score >= 40) return "medium";
  }
  return "low";
}

function removeBanner() {
  document.getElementById(BANNER_ID)?.remove();
}

function showBanner({ verdict, score, reasons, provider, savedToDashboard, source }) {
  removeBanner();

  const level = verdictToLevel(verdict, score);
  const banner = document.createElement("div");
  banner.id = BANNER_ID;
  banner.className = `swo-risk-${level}`;

  const safeScore = Math.max(0, Math.min(100, Number(score || 0)));
  const reasonItems = (reasons && reasons.length ? reasons : [
    "No major phishing indicators were detected.",
  ])
    .slice(0, 5)
    .map((r) => `<li>${escapeHtml(r)}</li>`)
    .join("");

  const providerText = provider === "gmail" ? "Gmail" : provider === "outlook" ? "Outlook" : "mailbox";
  const sourceText =
    source === "api"
      ? "External API"
      : source === "local"
      ? "Local browser heuristics"
      : "SecureWebOps";

  const footer = savedToDashboard
    ? "Saved to your SecureWebOps phishing history."
    : "Sign in via the extension popup to save these checks to your SecureWebOps dashboard.";

  banner.innerHTML = `
    <div class="swo-banner-header">
      <div class="swo-banner-title">SecureWebOps · ${escapeHtml(String(verdict || "Unknown"))}</div>
      <div class="swo-banner-badge">${level.toUpperCase()} · ${safeScore}/100</div>
    </div>
    <div class="swo-banner-meta">
      ${escapeHtml(providerText)} message analysis · ${escapeHtml(sourceText)}
    </div>
    <ul class="swo-banner-list">${reasonItems}</ul>
    <div class="swo-banner-footer">${escapeHtml(footer)}</div>
  `;

  return banner;
}

function renderBanner(injectionPoint, bannerEl) {
  if (!bannerEl) return;
  (injectionPoint || document.body).prepend(bannerEl);
}

async function getSession() {
  try {
    const data = await chrome.storage.local.get([SESSION_KEY]);
    return data[SESSION_KEY] || null;
  } catch {
    return null;
  }
}

async function setMailboxStatus(partial) {
  try {
    const data = await chrome.storage.local.get([MAILBOX_STATUS_KEY]);
    const current = data[MAILBOX_STATUS_KEY] || {};
    await chrome.storage.local.set({
      [MAILBOX_STATUS_KEY]: { ...current, ...partial },
    });
  } catch {}
}

async function saveToSupabase(payload) {
  const session = await getSession();
  if (!session?.access_token) return null;
  try {
    const response = await fetch(SUPABASE_FUNCTION_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error(`Save failed (${response.status})`);
    return await response.json();
  } catch (error) {
    console.warn("SecureWebOps save failed:", error);
    return null;
  }
}

function blendApiAndLocal(apiResult, localResult) {
  if (!apiResult) {
    return {
      verdict:
        localResult.level === "high"
          ? "Phishing"
          : localResult.level === "medium"
          ? "Suspicious"
          : "Safe",
      score: localResult.score,
      reasons: localResult.reasons.length ? localResult.reasons : ["No major phishing indicators were detected by local rules."],
      source: "local",
    };
  }
  return {
    verdict: apiResult.verdict,
    score: apiResult.score,
    reasons: apiResult.reasons || [],
    source: "api",
    emailTextApiRiskScore: apiResult.emailTextApiRiskScore,
    urlApiRiskScore: apiResult.urlApiRiskScore,
    linkHeuristicScore: apiResult.linkHeuristicScore,
  };
}

async function autoScanVisibleEmail() {
  if (isScanning) return;

  const data = extractEmailData();
  if (!data.adapterAvailable) {
    removeBanner();
    await setMailboxStatus({
      active: false,
      state: "inactive",
      lastSeenAt: new Date().toISOString(),
    });
    return;
  }
  if (!data.bodyText || data.bodyText.length < MIN_EMAIL_LENGTH) return;

  const hash = simpleHash(
    data.bodyText.slice(0, MAX_BODY_LENGTH) + "|" + data.subject + "|" + data.senderEmail
  );
  if (hash === lastScannedHash) return;
  lastScannedHash = hash;

  isScanning = true;
  try {
    const merged = window.PhishGuardRules?.analyzeEmail({
      subject: data.subject,
      bodyText: data.bodyText,
      senderEmail: data.senderEmail,
      replyToEmail: data.replyToEmail,
      links: data.links,
    }) || {
      verdict: "Safe",
      score: 0,
      level: "low",
      reasons: ["Local phishing rules were not available."],
      source: "local",
    };

    const session = await getSession();
    let savedToDashboard = false;
    let saveStatus = session?.access_token ? "save_failed" : "sign_in_required";
    let savedAt = null;
    if (session?.access_token) {
      const saved = await saveToSupabase({
        type: "email",
        content: data.bodyText.slice(0, MAX_BODY_LENGTH),
        subject: data.subject,
        senderEmail: data.senderEmail,
        verdict: merged.verdict,
        score: merged.score,
        reasons: merged.reasons,
      });
      if (saved) {
        savedToDashboard = true;
        saveStatus = "saved";
        savedAt = new Date().toISOString();
      }
    }

    const banner = showBanner({
      verdict: merged.verdict,
      score: merged.score,
      reasons: merged.reasons,
      provider: data.provider,
      savedToDashboard,
      source: merged.source,
    });
    renderBanner(data.injectionPoint, banner);

    if (
      merged.score >= 40 ||
      ["phishing", "suspicious", "high", "medium"].includes(
        String(merged.verdict).toLowerCase()
      )
    ) {
      highlightRiskyText(data.container);
    } else {
      removeOldHighlights();
    }

    await setMailboxStatus({
      active: true,
      state: "active",
      provider: data.provider,
      lastSeenAt: new Date().toISOString(),
      lastAnalyzedAt: new Date().toISOString(),
      saveStatus,
      savedAt,
      lastVerdict: merged.verdict,
      lastScore: merged.score,
      lastReasons: merged.reasons || [],
    });
  } finally {
    isScanning = false;
  }
}

function scheduleAutoScan() {
  clearTimeout(scanTimer);
  scanTimer = setTimeout(autoScanVisibleEmail, AUTO_SCAN_DELAY_MS);
}

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.action === "GET_EMAIL_TEXT") {
    const data = extractEmailData();
    sendResponse({ emailText: data.bodyText });
  }
  if (request.action === "GET_EMAIL_DATA") {
    const data = extractEmailData();
    sendResponse({
      subject: data.subject,
      senderEmail: data.senderEmail,
      replyToEmail: data.replyToEmail,
      emailText: data.bodyText,
      links: data.links.map((l) => ({ href: l.href, text: l.text, mismatch: l.mismatch })),
    });
  }
  if (request.action === "HIGHLIGHT_PHISHING_WORDS") {
    const data = extractEmailData();
    highlightRiskyText(data.container);
    sendResponse({ ok: true });
  }
});

injectStyles();
setTimeout(scheduleAutoScan, 2000);

const observer = new MutationObserver(scheduleAutoScan);
observer.observe(document.body, { childList: true, subtree: true });
