SecureWebOps Combined Extension - No Backend Version

Load this folder in Chrome:
1. Open chrome://extensions
2. Turn on Developer Mode
3. Click Load unpacked
4. Select this folder: securewebops-combined-no-backend

What changed:
- Removed localhost:3000 backend dependency.
- Phishing email scan now runs inside the extension using rules.js.
- Popup and Gmail/Outlook auto-scan both work without running node server.js.
- Website scanning still uses the SecureWebOps website API endpoints if your website backend is online.
- Supabase login/history still works only if your Supabase project and functions are active.

Important:
This no-backend version does NOT use OpenAI, Google Safe Browsing, or URLScan for phishing email scoring. It uses local phishing rules only.
