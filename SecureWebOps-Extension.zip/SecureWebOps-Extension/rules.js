// Local heuristic phishing scoring. No network calls.
// Exposes window.PhishGuardRules.

(function () {
  const URGENT_PHRASES = [
    "urgent", "immediately", "act now", "verify your account", "verify account",
    "suspended", "locked", "unusual activity", "security alert", "payment failed",
    "invoice overdue", "password expires", "confirm your identity", "update billing",
    "wire transfer", "gift card", "gift cards", "click below", "login to view",
    "reset password"
  ];

  const SUSPICIOUS_TLDS = ["zip", "mov", "top", "xyz", "click", "country", "kim", "work", "support"];

  const SHORTENERS = new Set([
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly",
    "buff.ly", "rebrand.ly", "rb.gy", "is.gd", "cutt.ly"
  ]);

  function safeLower(s) { return (s || "").toString().toLowerCase(); }

  function tryParseURL(url) {
    try { return new URL(url); } catch { return null; }
  }

  function getRegistrableDomain(hostname) {
    const parts = (hostname || "").split(".").filter(Boolean);
    if (parts.length <= 2) return parts.join(".");
    return parts.slice(-2).join(".");
  }

  function looksLikeIPAddress(hostname) {
    return /^\d{1,3}(\.\d{1,3}){3}$/.test(hostname || "");
  }

  function hasPunycode(hostname) { return (hostname || "").includes("xn--"); }

  function hasManySubdomains(hostname) {
    return (hostname || "").split(".").filter(Boolean).length >= 4;
  }

  function suspiciousTLD(hostname) {
    const parts = (hostname || "").split(".").filter(Boolean);
    return SUSPICIOUS_TLDS.includes(parts[parts.length - 1] || "");
  }

  function isShortener(hostname) {
    return SHORTENERS.has(getRegistrableDomain(hostname).toLowerCase());
  }

  function textContainsUrgency(text) {
    const t = safeLower(text);
    return URGENT_PHRASES.filter((p) => t.includes(p)).slice(0, 5);
  }

  function displayVsHrefMismatch(anchorLike) {
    const text = (anchorLike.textContent || "").trim();
    const href = anchorLike.getAttribute("href") || "";
    const u = tryParseURL(href.startsWith("http") ? href : "");
    if (!u) return null;

    const urlLike = text.match(/https?:\/\/[^\s]+/i)?.[0];
    if (!urlLike) return null;

    const textUrl = tryParseURL(urlLike);
    if (!textUrl) return null;

    const textDom = getRegistrableDomain(textUrl.hostname);
    const hrefDom = getRegistrableDomain(u.hostname);

    if (textDom && hrefDom && textDom !== hrefDom) return { textDom, hrefDom };
    return null;
  }

  function scoreEmail({ subject, bodyText, senderEmail, replyToEmail, links }) {
    let score = 0;
    const reasons = [];

    const urgencyHits = textContainsUrgency(`${subject || ""}\n${bodyText || ""}`);
    if (urgencyHits.length) {
      score += 20;
      reasons.push(`Urgent/pressure language: ${urgencyHits.join(", ")}`);
    }

    if (senderEmail && replyToEmail && safeLower(senderEmail) !== safeLower(replyToEmail)) {
      score += 20;
      reasons.push(`Reply-To differs from sender (${replyToEmail} vs ${senderEmail})`);
    }

    let suspiciousLinkCount = 0;
    for (const l of links || []) {
      const u = tryParseURL(l.href);
      if (!u) continue;
      const host = u.hostname || "";

      if (u.protocol !== "https:") {
        score += 10; suspiciousLinkCount++;
        reasons.push(`Non-HTTPS link: ${host}`);
      }
      if (looksLikeIPAddress(host)) {
        score += 20; suspiciousLinkCount++;
        reasons.push(`IP address used as link host: ${host}`);
      }
      if (hasPunycode(host)) {
        score += 25; suspiciousLinkCount++;
        reasons.push(`Punycode/IDN domain (possible lookalike): ${host}`);
      }
      if (hasManySubdomains(host)) {
        score += 10; suspiciousLinkCount++;
        reasons.push(`Many subdomains (hiding real domain): ${host}`);
      }
      if (suspiciousTLD(host)) {
        score += 10; suspiciousLinkCount++;
        reasons.push(`Suspicious TLD ".${host.split(".").pop()}": ${host}`);
      }
      if (isShortener(host)) {
        score += 15; suspiciousLinkCount++;
        reasons.push(`URL shortener used: ${host}`);
      }
      if (l.mismatch) {
        score += 25; suspiciousLinkCount++;
        reasons.push(`Misleading link text: shows ${l.mismatch.textDom} but goes to ${l.mismatch.hrefDom}`);
      }
    }

    if (suspiciousLinkCount >= 2) {
      score += 10;
      reasons.push(`Multiple suspicious links detected (${suspiciousLinkCount})`);
    }

    const lowerBody = safeLower(bodyText);
    if (lowerBody.includes("login") && (lowerBody.includes("verify") || lowerBody.includes("confirm"))) {
      score += 10;
      reasons.push(`Mentions login + verify/confirm (credential-harvest pattern)`);
    }

    score = Math.min(100, score);

    let level = "low";
    if (score >= 60) level = "high";
    else if (score >= 35) level = "medium";

    return { score, level, reasons: [...new Set(reasons)].slice(0, 8) };
  }


  function normalizeUrlString(raw) {
    let value = (raw || "").toString().trim().replace(/[),.;!?]+$/g, "");
    if (!/^https?:\/\//i.test(value)) return "";
    try {
      const url = new URL(value);
      if (url.hostname === "www.google.com" && url.pathname === "/url") {
        const q = url.searchParams.get("q");
        if (q) return normalizeUrlString(q);
      }
      if (url.hostname.includes("safelinks.protection.outlook.com")) {
        const wrapped = url.searchParams.get("url");
        if (wrapped) return normalizeUrlString(decodeURIComponent(wrapped));
      }
      return url.toString();
    } catch { return ""; }
  }

  function extractLinksFromText(text) {
    const rawText = (text || "").toString();
    const found = [];

    // 1) Real URLs pasted as plain text.
    const urlMatches = rawText.match(/https?:\/\/[^\s<>"']+/gi) || [];
    for (const raw of urlMatches) {
      const href = normalizeUrlString(raw);
      if (href) found.push({ href, text: href, mismatch: null, source: "text-url" });
    }

    // 2) Email clients often turn email addresses into clickable links in the DOM,
    // but when the user copies/pastes the message, those links become plain text.
    // To keep "Scan Visible Email" and "Analyze Pasted Text" consistent, convert
    // only sender-style email lines into a domain signal. Avoid treating every
    // recipient/forwarding address as a suspicious external link.
    const senderLineRegex = /(?:sent\s+from|from|sender|reply-to)\s*:?\s*<?([a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,}))>?/gi;
    let match;
    while ((match = senderLineRegex.exec(rawText)) !== null) {
      const fullEmail = match[1];
      const domain = match[2].toLowerCase();
      if (!domain || domain.includes("gmail.com") || domain.includes("googlemail.com")) continue;
      const href = normalizeUrlString(`https://${domain}`);
      if (href) found.push({ href, text: fullEmail, mismatch: null, source: "text-sender-email" });
    }

    return found;
  }

  function normalizeLinks(links, bodyText) {
    const seen = new Set();
    const out = [];
    function add(link) {
      const href = normalizeUrlString(link && link.href ? link.href : link);
      if (!href || seen.has(href)) return;
      seen.add(href);
      out.push({ href, text: (link && link.text) || href, mismatch: (link && link.mismatch) || null, source: (link && link.source) || "dom" });
    }
    (links || []).forEach(add);
    extractLinksFromText(bodyText).forEach(add);
    return out;
  }

  function verdictFromLevel(level) {
    if (level === "high") return "Phishing";
    if (level === "medium") return "Suspicious";
    return "Safe";
  }

  function analyzeEmail(input) {
    const normalizedLinks = normalizeLinks(input.links || [], input.bodyText || "");
    const base = scoreEmail({
      subject: input.subject || "",
      bodyText: input.bodyText || "",
      senderEmail: input.senderEmail || "",
      replyToEmail: input.replyToEmail || "",
      links: normalizedLinks,
    });
    let score = base.score;
    const reasons = [...(base.reasons || [])];
    if (normalizedLinks.length >= 2) {
      score += 30;
      reasons.push("Multiple links detected (phishing risk)");
    } else if (normalizedLinks.length === 1) {
      score += 15;
      reasons.push("Single external link detected");
    }
    if (normalizedLinks.some((l) => l.href.includes("forms.gle") || l.href.includes("docs.google.com/forms"))) {
      score += 10;
      reasons.push("Google Forms link detected (common phishing vector)");
    }
    score = Math.min(100, Math.max(0, score));
    const level = score >= 50 ? "high" : score >= 25 ? "medium" : "low";
    return {
      score,
      level,
      verdict: verdictFromLevel(level),
      reasons: [...new Set(reasons)].slice(0, 10),
      links: normalizedLinks,
      urlsChecked: normalizedLinks.map((l) => l.href),
      source: "local",
      linkHeuristicScore: score,
    };
  }
  window.PhishGuardRules = {
    tryParseURL,
    getRegistrableDomain,
    displayVsHrefMismatch,
    scoreEmail,
    normalizeUrlString,
    extractLinksFromText,
    normalizeLinks,
    analyzeEmail
  };
})();
