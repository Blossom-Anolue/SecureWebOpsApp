document.getElementById("scanBtn").addEventListener("click", () => {
    const url = document.getElementById("urlInput").value;
    const statusText = document.getElementById("status");
  
    if (!url) {
      statusText.textContent = "Please enter a URL.";
      return;
    }
  
    statusText.textContent = "Sending scan request...";
  
    // Keep this as a mock for now, backend will connect later
    setTimeout(() => {
      statusText.textContent = "Scan sent! View results in SecureWebOps Dashboard.";
    }, 1500);
  });
  