console.log("popup.js loaded");

document.addEventListener("DOMContentLoaded", () => {
  const scanBtn = document.getElementById("scanBtn");
  const openDashboardBtn = document.getElementById("openDashboard");
  const viewBtn = document.getElementById("loginBtn");
  const urlInput = document.getElementById("urlInput");
  const statusText = document.getElementById("status");

  // ✅ Your Node server (reachable from Windows/Brave)
  const API_BASE = "http://172.20.0.220:3000";
  const BACKEND_SCAN_URL = `${API_BASE}/api/scan`;

  // SecureWebOps site where the Supabase auth token lives
  const SECUREWEBOPS_TAB_MATCH = "https://securewebops.gannon.link/*";

  // Your Supabase project id (used for localStorage key)
  const SUPABASE_PROJECT_ID = "culznwivxwtvrmohstht";
  const STORAGE_KEY = `sb-${SUPABASE_PROJECT_ID}-auth-token`;

  function setStatus(msg) {
    console.log("STATUS:", msg);
    if (statusText) statusText.textContent = msg;
  }

  function normalizeUrl(input) {
    let v = (input || "").trim();
    if (!v) return null;
    if (!v.startsWith("http://") && !v.startsWith("https://")) v = "https://" + v;
    try {
      const u = new URL(v);
      return (u.protocol === "http:" || u.protocol === "https:") ? u.toString() : null;
    } catch {
      return null;
    }
  }

  async function getSecureWebOpsTab() {
    const tabs = await chrome.tabs.query({ url: SECUREWEBOPS_TAB_MATCH });
    if (!tabs || tabs.length === 0) return null;
    return tabs.find(t => t.active) || tabs[0];
  }

  async function getAccessTokenFromTab(tabId) {
    // Uses chrome.scripting (no contentScript required)
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (storageKey) => {
        const raw = window.localStorage.getItem(storageKey);
        if (!raw) return { ok: false, error: `No token found (not logged in yet).` };

        let parsed;
        try { parsed = JSON.parse(raw); } catch (e) {
          return { ok: false, error: "Token exists but JSON parse failed: " + String(e) };
        }

        const accessToken = parsed?.access_token;
        if (!accessToken) return { ok: false, error: "Token found but access_token missing." };

        return { ok: true, accessToken };
      },
      args: [STORAGE_KEY]
    });

    const first = results?.[0]?.result;
    if (!first?.ok) return null;
    return first.accessToken;
  }

  async function submitScan(url) {
    // IMPORTANT: do NOT auto-open/focus tabs here (that closes the popup)
    const tab = await getSecureWebOpsTab();
    if (!tab) {
      throw new Error("Open SecureWebOps in a tab and log in first, then come back and scan.");
    }

    const token = await getAccessTokenFromTab(tab.id);
    if (!token) {
      throw new Error("Missing Authorization: Bearer <token>. Click 'Open SecureWebOps', log in, then try again.");
    }

    const resp = await fetch(BACKEND_SCAN_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ url, scanType: "quick" })
    });

    const raw = await resp.text();
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }

    if (!(resp.status === 200 || resp.status === 202)) {
      const msg = body?.error || body?.raw || `HTTP ${resp.status}`;
      throw new Error(msg);
    }

    return body;
  }

  scanBtn.addEventListener("click", async () => {
    const target = normalizeUrl(urlInput.value);
    if (!target) return setStatus("Enter a valid URL.");

    scanBtn.disabled = true;
    setStatus("Submitting scan...");

    try {
      const result = await submitScan(target);

      // accept scanId or scan_id
      const scanId = result?.scanId || result?.scan_id || null;

      await chrome.storage.local.set({ lastSubmittedScanId: scanId });
      if (viewBtn) viewBtn.style.display = scanId ? "block" : "none";

      setStatus(scanId ? `Submitted ✅ Scan ID: ${scanId}` : "Submitted ✅");
    } catch (err) {
      console.error(err);
      setStatus(`Error: ${err?.message || String(err)}`);
    } finally {
      scanBtn.disabled = false;
    }
  });

  openDashboardBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://securewebops.gannon.link" });
  });

  viewBtn.addEventListener("click", () => {
    chrome.storage.local.get(["lastSubmittedScanId"], (data) => {
      const scanId = data.lastSubmittedScanId;
      const url = scanId
        ? `https://securewebops.gannon.link/scans` // simplest stable destination
        : "https://securewebops.gannon.link/scans";
      chrome.tabs.create({ url });
    });
  });

  chrome.storage.local.get(["lastSubmittedScanId"], (data) => {
    if (viewBtn) viewBtn.style.display = data.lastSubmittedScanId ? "block" : "none";
  });

  setStatus("Ready.");
});